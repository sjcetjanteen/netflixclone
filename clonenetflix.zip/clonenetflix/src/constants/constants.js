export const baseUrl='https://api.themoviedb.org/3';
export const API_KEY ="d03799692be1c26faf0ade18a4205f9f";
export const imageUrl ='https://image.tmdb.org/t/p/original';